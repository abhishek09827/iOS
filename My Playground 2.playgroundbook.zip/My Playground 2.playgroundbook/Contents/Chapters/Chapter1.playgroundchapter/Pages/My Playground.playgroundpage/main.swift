class Vehicle {
    var currentSpeed = 0.0
      
    var description: String {
        "traveling at \(currentSpeed) miles per hour"
    }
      
    func makeNoise() {
        
        print("make a noise")
    }
}
 
let someVehicle = Vehicle()
print("Vehicle: \(someVehicle.description)")
