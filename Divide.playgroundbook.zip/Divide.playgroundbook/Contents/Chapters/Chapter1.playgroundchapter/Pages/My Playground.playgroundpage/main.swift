func divide(firstNumber: Int , secondNumber: Int) -> Int {
    var result = firstNumber / secondNumber
    if secondNumber == 0{
        let result = secondNumber/firstNumber
        
    }
    else{
        result = firstNumber / secondNumber
        
        
        
    }
    print("\(result) is the answer")
    return result
    
}

let myResult = divide(firstNumber: 10, secondNumber: 5)
print("10 * 5 is \(myResult)")


